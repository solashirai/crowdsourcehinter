Clazz.declarePackage ("org.jmol.io2");
Clazz.load (["java.util.zip.ZipInputStream", "org.jmol.api.ZInputStream"], "org.jmol.io2.JmolZipInputStream", null, function () {
c$ = Clazz.declareType (org.jmol.io2, "JmolZipInputStream", java.util.zip.ZipInputStream, org.jmol.api.ZInputStream);
});
