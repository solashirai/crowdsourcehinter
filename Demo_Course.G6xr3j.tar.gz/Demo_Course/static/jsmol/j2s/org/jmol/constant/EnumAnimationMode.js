Clazz.declarePackage ("org.jmol.constant");
Clazz.load (["java.lang.Enum"], "org.jmol.constant.EnumAnimationMode", null, function () {
c$ = Clazz.declareType (org.jmol.constant, "EnumAnimationMode", Enum);
Clazz.defineEnumConstant (c$, "ONCE", 0, []);
Clazz.defineEnumConstant (c$, "LOOP", 1, []);
Clazz.defineEnumConstant (c$, "PALINDROME", 2, []);
});
