Clazz.declarePackage ("org.jmol.constant");
Clazz.load (["java.lang.Enum"], "org.jmol.constant.EnumStereoMode", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.$$name = null;
this.$isBiColor = false;
Clazz.instantialize (this, arguments);
}, org.jmol.constant, "EnumStereoMode", Enum);
Clazz.makeConstructor (c$, 
($fz = function (name, isBiColor) {
this.$$name = name;
this.$isBiColor = isBiColor;
}, $fz.isPrivate = true, $fz), "~S,~B");
Clazz.defineMethod (c$, "getName", 
function () {
return this.$$name;
});
Clazz.defineMethod (c$, "isBiColor", 
function () {
return this.$isBiColor;
});
c$.getStereoMode = Clazz.defineMethod (c$, "getStereoMode", 
function (id) {
for (var item, $item = 0, $$item = org.jmol.constant.EnumStereoMode.values (); $item < $$item.length && ((item = $$item[$item]) || true); $item++) if (item.$$name.equalsIgnoreCase (id)) return item;

return null;
}, "~S");
c$.DEFAULT_STEREO_DEGREES = -5;
Clazz.defineEnumConstant (c$, "NONE", 0, ["OFF", false]);
Clazz.defineEnumConstant (c$, "DOUBLE", 1, ["", false]);
Clazz.defineEnumConstant (c$, "REDCYAN", 2, ["REDCYAN", true]);
Clazz.defineEnumConstant (c$, "REDBLUE", 3, ["REDBLUE", true]);
Clazz.defineEnumConstant (c$, "REDGREEN", 4, ["REDGREEN", true]);
Clazz.defineEnumConstant (c$, "CUSTOM", 5, ["", true]);
});
