Clazz.declarePackage ("org.jmol.modelset");
Clazz.declareInterface (org.jmol.modelset, "BondIterator");
