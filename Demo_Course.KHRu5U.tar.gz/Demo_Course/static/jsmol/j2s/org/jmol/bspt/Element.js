Clazz.declarePackage ("org.jmol.bspt");
c$ = Clazz.decorateAsClass (function () {
this.bspt = null;
this.count = 0;
Clazz.instantialize (this, arguments);
}, org.jmol.bspt, "Element");
