Clazz.declarePackage ("org.jmol.rendersurface");
Clazz.load (["org.jmol.rendersurface.PmeshRenderer"], "org.jmol.rendersurface.Plot3DRenderer", null, function () {
c$ = Clazz.declareType (org.jmol.rendersurface, "Plot3DRenderer", org.jmol.rendersurface.PmeshRenderer);
});
