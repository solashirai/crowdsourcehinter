Clazz.declarePackage ("org.jmol.adapter.smarter");
c$ = Clazz.decorateAsClass (function () {
this.atomSetIndex = 0;
Clazz.instantialize (this, arguments);
}, org.jmol.adapter.smarter, "AtomSetObject");
