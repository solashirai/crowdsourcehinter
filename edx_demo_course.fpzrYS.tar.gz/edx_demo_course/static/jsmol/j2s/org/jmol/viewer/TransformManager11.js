Clazz.declarePackage ("org.jmol.viewer");
c$ = Clazz.declareType (org.jmol.viewer, "TransformManager11");
