Clazz.declarePackage ("org.jmol.api");
Clazz.load (["org.jmol.api.JmolSyncInterface"], "org.jmol.api.JmolScriptInterface", null, function () {
Clazz.declareInterface (org.jmol.api, "JmolScriptInterface", org.jmol.api.JmolSyncInterface);
});
